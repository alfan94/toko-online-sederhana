@extends('layouts.app')

@section('content')
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <a href="{{url('home')}}" class="btn btn-primary"><i class="fa fa-arrow-left"></i>Back</a>
    <div>
    <div class="col-md-14 mt-2">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{url('home')}}">Home</a></li>
    <li class="breadcrumb-item"><a href="">{{$produk->nama_barang}}</a></li>
    </ol>
    </nav>
    </div>
    <div class="card-body">
    <div class="row">
    <div class="col-md-6">
    dsfsdf
    </div>
    <div class="col-md-6">
    <div class="card-header"><h4>{{$produk->nama_barang}}</h4>
    <table>
    <thead>
     <tr>
     <td>Harga :</td>
     <td>Rp.  {{number_format($produk->harga)}}</td>
     </tr>
     <tr>
     <td>Stok:</td>
     <td>{{$produk->stok}}</td>
    
     </tr>
     <form action="{{url('pesan')}}/{{$produk->id}}" method="post">
     <tr>
     @csrf
     <td>Jumlah Pesan:</td>
     <td><input type="number" name="jumlah_pesan" class="form-control" required>
     </td>
     </tr>
     <tr>
     <td></td>
   
     <td><button type="submit" class="btn btn-primary mt-3"><i class="fa fa shopping-cart fa-2x"  ></i>masukkan keranjang</button>
    </tr>

    
     </form>
     </td>

     </table>
    
    </div>
    </div>
    </div>
    </div>
  
    </div>
  
  
  </div>
</div>
@endsection
