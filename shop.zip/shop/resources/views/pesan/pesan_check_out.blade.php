@extends('layouts.app')

@section('content')
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <a href="{{url('home')}}" class="btn btn-primary"><i class="fa fa-arrow-left"></i>Back</a>
    <div>
    <div class="col-md-14 mt-2">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{url('home')}}">Home</a></li>
    <li class="breadcrumb-item"><a href=""></a>Check Out</li>
    </ol>
    </nav>
    </div>
  <div class="col-md-14 mt-2">
      <div class="card">
       <div class="card-header">  <h3><i class="fa fa-shopping-cart">Check Out</i></h3>
     @if(!empty($pesanan))
     
     <h3>Tanggal Pesan : {{$pesanan->tanggal}}</h3>

       <div class="card-body">        <table class="table table-bordered table-striped">
        <thead>
        <tr>
        <td>No</td>
        <td>Nama Barang</td>
        <td>jumlah</td>
        <td>Harga</td>
        <td>Total Harga</td>
        <td>Aksi</td>
        </tr>
        <thead>
        <tbody>
        <?php $no=1;?>
        @foreach( $pesanan_detail as $detail)
        <tr>
        <td>{{$no++}}</td>
        <td>{{$detail->barang->nama_barang}}</td>
        <td>{{$detail->jumlah}}</td>
        <td align="left">Rp. {{number_format($detail->barang->harga)}}</td>
        <td align="left">Rp. {{number_format($detail->jumlah_harga)}}</td>
        <td><form action="{{url('checkout')}}/{{$detail->id}}"method="post">
        @csrf
        @method('delete')
        <button class="btn btn-danger" type="submit"><i class="fa fa-trash"></i></button>
        </form>
        </td>
        </tr>
        @endforeach
        <tr>
        <td colspan="4">Total Harga semua</td>
        <td > Rp. {{number_format($pesanan->jumlah_harga)}}</td>
        <td> <a href="{{url('konfirmasi')}}" class="btn btn-primary"><i class="fa fa-shopping-cart">Check Out</i></a></td>
        </tbody>
        </table>
        @endif
        </div>
  </div>
  </div>

  </div>
</div>
@endsection
