@extends('layouts.app')

@section('content')
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <a href="{{url('home')}}" class="btn btn-primary"><i class="fa fa-arrow-left"></i>Back</a>
    <div>
    <div class="col-md-14 mt-2">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="{{url('home')}}">Home</a></li>
    <li class="breadcrumb-item"><a href=""></a>Check Out</li>
    </ol>
    </nav>
    </div>
  <div class="col-md-14 mt-2">
      <div class="card">
       <div class="card-header">  <h3><i class="fa fa-shopping-cart">Riwayat pemesanan</i></h3>

     
    
       <div class="card-body">        <table class="table table-bordered table-striped">
        <thead>
        <tr>
        <td>No</td>
        <td>Tanggal</td>
        <td>Status</td>
        <td>Jumlah Harga</td>
        <td>Detail</td>
    
        </tr>
        <thead>
        <tbody>
        <?php $no=1;?>
        @foreach( $pesanan  as $detail)
        <tr>
        <td>{{$no++}}</td>
        <td>{{$detail->tanggal}}</td>
        <td>
        <?php
        if($detail->status==1)
        {
          echo 'belum dibayar';
        }else{
       echo 'sudah dibayar';
        }
        ?>
        </td>
                <td align="left">Rp. {{number_format($detail->jumlah_harga + $detail->kode)}}</td>
       
       <td><a href="{{'history'}}/{{$detail->id}}"class="btn btn-primary">Detail</a>
         </tbody>
        </table>
        @endforeach
        </div>
  </div>
  </div>

  </div>
</div>
@endsection
