@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
       
       <div class="col-md-12 mb-5">
       <img src="{{url('image/w.jpg')}}" class="rounded mx-auto d-block" width="800px" height="200px" alt="">
       </div>
       @foreach($produk as $barang)
  <div class="col-md-4">

      <div class="card" style="width:18rem;">
       <img src="" class="card-img-top" alt="">
       <div class="card-body">
       <h5 class="card-title">{{$barang->nama_barang}}</h5>
       <p class="card-text" >Harga : Rp. {{number_format($barang->harga)}}<br>
        Stok     : {{$barang->stok}}<br>
        <hr>
        Keterangan:<br>
        {{$barang->keterangan}}
        </p>
       <a href="{{url('pesan')}}/{{$barang->id}}"class="btn btn-primary"><i class="fa fa-shopping-cart">Pesan</i></a>
       </div>
  </div>

  </div>
       @endforeach
       
    </div>
</div>
<?php


?>
@endsection
