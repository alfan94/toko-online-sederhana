<?php

namespace App\Http\Controllers;


use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Http\Request;
Use App\Barang;
use Illuminate\Support\Facades\Hash;
Use App\Pesanans;
Use App\user;
Use App\PesananDetails;
use Carbon\Carbon;
Use Illuminate\Support\Facades\Auth;



class ProfileController extends Controller
{
    public function __construct()
    {
   $this->middleware('auth');

    }

public function bane()
    {

 $user= User::where('id',Auth::user()->id)->first();

   return view('profile.index',compact('user'));

    }


public function edit(Request $request)
{
  
 $request->validate([
    'nohp'=>'min:12',
     'password'=>'min:8|confirmed',
 ]);

    $user= User::where('id',Auth::user()->id)->first();

    $user->name=$request->name;
    $user->email=$request->email;
    $user->alamat=$request->alamat;
    $user->nohp=$request->nohp;

    if(!empty($request->password))
    {
        $user->password=hash::make($request->passsword);
   

    }
   $user->update();

   Alert::success('Success', 'data profil berhasil diupdate');
   return redirect('profile');
   
}



}
