<?php

namespace App\Http\Controllers;
use RealRashid\SweetAlert\Facades\Alert;

Use App\Barang;
Use App\User;
Use App\Pesanans;
Use App\PesananDetails;
use Carbon\Carbon;
Use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class HistoryController extends Controller
{
    public function __construct()
{
   $this->middleware('auth');
}

public function index()
{
   $pesanan=pesanans::where('user_id',Auth::user()->id)->where('status','!=',0)->get();
   return view('history.index',compact('pesanan'));
}
public function detail($id)
{
$pesanan=Pesanans::where('id',$id)->first();

$pesanan_detail=PesananDetails::where('pesanan_id',$pesanan->id)->get();

return view('history.detail',compact('pesanan','pesanan_detail'));

}


}
