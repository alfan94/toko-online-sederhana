<?php

namespace App\Http\Controllers;
use RealRashid\SweetAlert\Facades\Alert;
use Illuminate\Http\Request;
Use App\Barang;
Use App\User;
Use App\Pesanans;
Use App\PesananDetails;
use Carbon\Carbon;
Use Illuminate\Support\Facades\Auth;

class PesanController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

public function index($id)
{

  $produk=barang::where('id',$id)->first();
 
  return view('pesan.pesan',compact('produk'));

}

public function pesan(Request $request,$id)
{
     $produk=barang::where('id',$id)->first();
      $tanggal=Carbon::now();

     //simpan kedatabase pesanan
     
//validasi jumlah stok barang
if($request->jumlah_pesan > $produk->stok)
{
  return redirect('pesan/'.$id);
}
//cek validasi id pesnana
     $cek_pesanan=Pesanans::where('user_id',Auth::user()->id)->where('status',0)->first();
     if(empty($cek_pesanan))
     {
     $pesanan=new pesanans;
     $pesanan->user_id=Auth::user()->id;
     $pesanan->tanggal=$tanggal;
     $pesanan->status=0;
     $pesanan->jumlah_harga=0;//$produk->harga * $request->jumlah_pesan;;
     $pesanan->kode=mt_rand(100,999);
     $pesanan->save();
     }
     //simpan kedatabse pesanan detail
$pesanan_baru=Pesanans::where('user_id',auth::user()->id)->where('status',0)->first();
    

//cek apakah pesan sdah ada atau belum
$cek_detail=PesananDetails::where('barang_id',$produk->id)->where('pesanan_id',$pesanan_baru->id)->first();

if(empty($cek_detail))
{
$pesanan_detail= new PesananDetails;
     $pesanan_detail->barang_id = $produk->id;
     $pesanan_detail->pesanan_id = $pesanan_baru->id;
     $pesanan_detail->jumlah_harga=$request->jumlah_pesan * $produk->harga;
     $pesanan_detail->jumlah=$request->jumlah_pesan;
     $pesanan_detail->save();
}else{
  $pesanan_detail=PesananDetails::where('barang_id',$produk->id)->where('pesanan_id',$pesanan_baru->id)->first();

     $pesanan_detail->jumlah= $pesanan_detail->jumlah + $request->jumlah_pesan;
     $pesanan_baru->jumlah_harga=$request->jumlah_pesan * $produk->harga;
     $pesanan_detail->jumlah_harga=$pesanan_detail->jumlah_harga + $pesanan_baru->jumlah_harga;
     $pesanan_detail->update();


}

//jumlah total pada pesanan

$pesanan=Pesanans::where('user_id',Auth::user()->id)->where('status',0)->first();

$pesanan->jumlah_harga=$pesanan->jumlah_harga + $request->jumlah_pesan * $produk->harga;
$pesanan->update();


Alert::info('Success', 'pesananmu telah masuk dalam keranjang');
return redirect('home');



}
//tampilkan pesanan detail
public function checkout()
{

  $pesanan=Pesanans::where('user_id',Auth::user()->id)->where('status',0)->first();
$pesanan_detail=[];
if(!empty($pesanan))
{ 

   $pesanan_detail=PesananDetails::where('pesanan_id',$pesanan->id)->get();
}
   return view('pesan.pesan_check_out',compact('pesanan_detail','pesanan'));

}
public function delete($id)
{

 $pesanan_detail=PesananDetails::where('id',$id)->first();
  $pesanan=Pesanans::where('id',$pesanan_detail->pesanan_id)->first();

  $pesanan->jumlah_harga=$pesanan->jumlah_harga - $pesanan_detail->jumlah_harga;
  $pesanan->update();

  $pesanan_detail->delete();
  Alert::error('Sukses Dihapus', 'pesananmu sukses dihapus');
  return view('checkout',compact('pesanan_detail','pesanan'));


} 

public function konfirmasi()
{
 $user=User::where('id',Auth::user()->id)->first();

  if(empty($user->nohp && $user->alamat))
  {
    Alert::error('confirmasi gagal', 'silahkan isi alamat dan nohp');
    return redirect('profile');
  }

  $pesanan=Pesanans::where('user_id',Auth::user()->id)->where('status',0)->first();
 $pesanan_id=$pesanan->id;
  $pesanan->status=0;
 $pesanan->update();


 $pesanan_detail=PesananDetails::where('pesanan_id',$pesanan_id)->get();
 
 foreach($pesanan_detail as $pesanan_detail)
 {
    $produks=Barang::where('id',$pesanan_detail->barang_id)->first();
    $produks->stok=$produks->stok - $pesanan_detail->jumlah;
    $produks->update();

 }
$pesanan->status=1;
$pesanan->update();



Alert::success('Sukses checkout', 'silahkan transfer sesuai tiket');
 return redirect('histori/'.$pesanan_id);
}

}
