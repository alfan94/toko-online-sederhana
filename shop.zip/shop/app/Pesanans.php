<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pesanans extends Model
{
    public function user()

    {
       return $this->belongsTo("App\User",'user_id','id');

    }

    public function pesananDetails()

    {
       return $this->hasMany("App\PesananDetails",'pesanan_id','id');

    }
       

}
