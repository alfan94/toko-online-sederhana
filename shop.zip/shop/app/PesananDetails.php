<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PesananDetails extends Model
{

    protected $table=('pesanan_details');

public function barang()
{

    return $this->belongsTo("App\barang","barang_id","id");
}

public function pesanan()

{
    return $this->belongsTo('App\PesananDetails','pesanan_id','id');
}
}
 