<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Barang extends Model
{
    protected $table='barangs';
    protected $fillable=['nama_barang','harga','stok','keterangan'];

public function Pesanan()
{
  
     return $this->hasMany("App/Pesanans","pesanan_id","id");

}
}