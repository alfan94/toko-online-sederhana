

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <a href="<?php echo e(url('home')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i>Back</a>
    <div>
    <div class="col-md-14 mt-2">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href=""></a>Check Out</li>
    </ol>
    </nav>
    </div>
  <div class="col-md-14 mt-2">
      <div class="card">
       <div class="card-header">  <h3><i class="fa fa-shopping-cart">Riwayat pemesanan</i></h3>

     
    
       <div class="card-body">        <table class="table table-bordered table-striped">
        <thead>
        <tr>
        <td>No</td>
        <td>Tanggal</td>
        <td>Status</td>
        <td>Jumlah Harga</td>
        <td>Detail</td>
    
        </tr>
        <thead>
        <tbody>
        <?php $no=1;?>
        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($no++); ?></td>
        <td><?php echo e($detail->tanggal); ?></td>
        <td>
        <?php
        if($detail->status==1)
        {
          echo 'belum dibayar';
        }else{
       echo 'sudah dibayar';
        }
        ?>
        </td>
                <td align="left">Rp. <?php echo e(number_format($detail->jumlah_harga + $detail->kode)); ?></td>
       
       <td><a href="<?php echo e('history'); ?>/<?php echo e($detail->id); ?>"class="btn btn-primary">Detail</a>
         </tbody>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
  </div>
  </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project laravel\toko onlne\shop\resources\views/history/index.blade.php ENDPATH**/ ?>