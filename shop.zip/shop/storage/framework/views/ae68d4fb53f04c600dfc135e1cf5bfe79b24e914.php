

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <a href="<?php echo e(url('home')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i>Back</a>
    <div>
    <div class="col-md-14 mt-2">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href=""></a>Check Out</li>
    </ol>
    </nav>
    </div>
  <div class="col-md-14 mt-2">
      <div class="card">
       <div class="card-header">  <h3><i class="fa fa-shopping-cart">Check Out</i></h3>
     <?php if(!empty($pesanan)): ?>
     
     <h3>Sukses checkout<h3>
     <h5>Pesanan anda sudah sukses checkput selanjutnya untuk pmbayaran silahkan transliterator_create_from_rules
       kerekening <strong>BCA 3335555 dengan nominal wajib sesuai tiket Rp. <?php echo e(number_format($pesanan->jumlah_harga+$pesanan->kode)); ?> <strong>

       <div class="card-body">        <table class="table table-bordered table-striped">
        <thead>
        <tr>
        <td>No</td>
        <td>Nama Barang</td>
        <td>jumlah</td>
        <td>Harga</td>
        <td>Total Harga</td>
       
        </tr>
        <thead>
        <tbody>
        <?php $no=1;?>
        <?php $__currentLoopData = $pesanan_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($no++); ?></td>
        <td><?php echo e($detail->barang->nama_barang); ?></td>
        <td><?php echo e($detail->jumlah); ?></td>
      
        <td align="left">Rp. <?php echo e(number_format($detail->barang->harga)); ?></td>
        <td align="left">Rp. <?php echo e(number_format($detail->jumlah_harga)); ?></td>
       
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td colspan="4">Total Harga semua</td>
        <td > Rp. <?php echo e(number_format($pesanan->jumlah_harga)); ?></td>
        </tr>
        <tr>
        <td colspan="4">Kode Unik</td>
        <td > Rp. <?php echo e(number_format($pesanan->kode)); ?></td>
        </tr>
        <tr>
        <td colspan="4">yang harus ditransfer</td>
        <td > Rp. <?php echo e(number_format($pesanan->jumlah_harga+$pesanan->kode)); ?></td>
        </tr>
         </tbody>
        </table>
        <?php endif; ?>
        </div>
  </div>
  </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project laravel\toko onlne\shop\resources\views/history/detail.blade.php ENDPATH**/ ?>