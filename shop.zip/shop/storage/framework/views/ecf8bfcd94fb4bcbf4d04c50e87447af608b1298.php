<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
       
       <div class="col-md-12 mb-5">
       <img src="<?php echo e(url('image/w.jpg')); ?>" class="rounded mx-auto d-block" width="800px" height="200px" alt="">
       </div>
       <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col-md-4">

      <div class="card" style="width:18rem;">
       <img src="" class="card-img-top" alt="">
       <div class="card-body">
       <h5 class="card-title"><?php echo e($barang->nama_barang); ?></h5>
       <p class="card-text" >Harga : Rp. <?php echo e(number_format($barang->harga)); ?><br>
        Stok     : <?php echo e($barang->stok); ?><br>
        <hr>
        Keterangan:<br>
        <?php echo e($barang->keterangan); ?>

        </p>
       <a href="<?php echo e(url('pesan')); ?>/<?php echo e($barang->id); ?>"class="btn btn-primary"><i class="fa fa-shopping-cart">Pesan</i></a>
       </div>
  </div>

  </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    </div>
</div>
<?php


?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project laravel\toko onlne\shop\resources\views/home.blade.php ENDPATH**/ ?>