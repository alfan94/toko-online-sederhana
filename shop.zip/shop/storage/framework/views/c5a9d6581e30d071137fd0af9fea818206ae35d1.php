

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <a href="<?php echo e(url('home')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i>Back</a>
    <div>
    <div class="col-md-14 mt-2">
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href=""><?php echo e($produk->nama_barang); ?></a></li>
    </ol>
    </nav>
    </div>
    <div class="card-body">
    <div class="row">
    <div class="col-md-6">
    dsfsdf
    </div>
    <div class="col-md-6">
    <div class="card-header"><h4><?php echo e($produk->nama_barang); ?></h4>
    <table>
    <thead>
     <tr>
     <td>Harga :</td>
     <td>Rp.  <?php echo e(number_format($produk->harga)); ?></td>
     </tr>
     <tr>
     <td>Stok:</td>
     <td><?php echo e($produk->stok); ?></td>
    
     </tr>
     <form action="<?php echo e(url('pesan')); ?>/<?php echo e($produk->id); ?>" method="post">
     <tr>
     <?php echo csrf_field(); ?>
     <td>Jumlah Pesan:</td>
     <td><input type="number" name="jumlah_pesan" class="form-control" required>
     </td>
     </tr>
     <tr>
     <td></td>
   
     <td><button type="submit" class="btn btn-primary mt-3"><i class="fa fa shopping-cart fa-2x"  ></i>masukkan keranjang</button>
    </tr>

    
     </form>
     </td>

     </table>
    
    </div>
    </div>
    </div>
    </div>
  
    </div>
  
  
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project laravel\toko onlne\shop\resources\views/pesan/pesan.blade.php ENDPATH**/ ?>